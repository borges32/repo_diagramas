# Cart Alert - Plugin Grafana de Alertas em Card

Plugin de painel (panel plugin) para Grafana que exibe os **Alert Rules** em formato de cards elegantes, respeitando as cores de severidade, com hover de descrição, link para Runbook e diversos parâmetros de customização visual.

## Recursos

- Cards com **summary**, **expressão (script)** e **estado** do alerta
- Cor do card seguindo o estado (`firing`, `pending`, `normal`, `no_data`, `error`)
- **Hover** mostra a `description` completa do alerta
- Ícone clicável que abre o **Runbook URL**
- Opções de customização: colunas, tamanho do card, exibir/ocultar expressão, filtro por label, paleta de cores etc.

## Estrutura

```
cart_alert/
├── docker-compose.yml          # Stack: Grafana + Prometheus + OTel Collector + Generator
├── provisioning/               # Datasources e regras de alerta provisionadas
├── prometheus/                 # Config do Prometheus
├── otel/                       # Config do OpenTelemetry Collector
├── metric-generator/           # Container que envia métricas OTLP
└── plugin/                     # Plugin Grafana (TypeScript + React)
```

## Como rodar

```bash
# 1. Build do plugin
cd plugin
npm install
npm run build
cd ..

# 2. Sobe a stack
docker compose up -d

# 3. Acesse o Grafana
# http://localhost:3000  (admin / admin)
```

O plugin já fica provisionado em modo "unsigned dev" via variável de ambiente do Grafana
(`GF_PLUGINS_ALLOW_LOADING_UNSIGNED_PLUGINS=cartalert-alerts-panel`).

Crie um novo painel e selecione **Cart Alert - Alerts Cards** como visualização.

## Customização (Panel Options)

| Opção | Descrição |
|-------|-----------|
| Colunas | Número de cards por linha (1–6) |
| Mostrar expressão | Exibe/oculta o script PromQL do alerta |
| Filtro por label | Regex aplicada sobre os labels |
| Cor Firing | Cor customizada do estado firing |
| Cor Pending | Cor customizada do estado pending |
| Cor Normal | Cor customizada do estado normal |
| Raio do card | Border radius |
| Espaçamento | Gap entre cards |

## Fonte dos dados

O painel consulta a API interna do Grafana
(`/api/prometheus/grafana/api/v1/rules`) — ou seja, retorna todas as alert rules
geridas pelo próprio Grafana, sem necessidade de data source no painel.
