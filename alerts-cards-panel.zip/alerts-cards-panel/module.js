define(["@grafana/data","react","@emotion/css","@grafana/ui","@grafana/runtime"],(e,a,t,r,o)=>(()=>{"use strict";var n={89(e){e.exports=t},781(a){a.exports=e},531(e){e.exports=o},7(e){e.exports=r},959(e){e.exports=a}},l={};function i(e){var a=l[e];if(void 0!==a)return a.exports;var t=l[e]={exports:{}};return n[e](t,t.exports,i),t.exports}i.n=e=>{var a=e&&e.__esModule?()=>e.default:()=>e;return i.d(a,{a}),a},i.d=(e,a)=>{for(var t in a)i.o(a,t)&&!i.o(e,t)&&Object.defineProperty(e,t,{enumerable:!0,get:a[t]})},i.o=(e,a)=>Object.prototype.hasOwnProperty.call(e,a),i.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})};var s={};i.r(s),i.d(s,{plugin:()=>w});var c=i(781);const d=["firing","pending","normal","nodata","error"],p={columns:3,showExpression:!0,labelFilter:"",stateFilter:[...d],groupFilter:"",sortBy:"severity",hideEmptyGroups:!0,colorFiring:"#E02F44",colorPending:"#FF9830",colorNormal:"#3BA55D",colorNoData:"#8E8E8E",colorError:"#7E2EC9",borderRadius:12,gap:16,compact:!1,showFooter:!0,cardMaxHeight:220,cardMinHeight:0};var u=i(959),m=i.n(u),g=i(89),x=i(7),f=i(531);function h(e){switch((e||"").toLowerCase()){case"firing":return"firing";case"pending":return"pending";case"nodata":case"no_data":return"nodata";case"error":return"error";default:return"normal"}}const b=({alert:e,color:a,showExpression:t,showFooter:r,borderRadius:o,compact:n,maxHeight:l,minHeight:i})=>{const s=e.annotations.summary||e.name,c=e.annotations.description||"Sem descrição disponível.",d=e.annotations.runbook_url||e.annotations.runbookUrl,p=e.labels.severity,u=v(a,o,n,l,i);return m().createElement("div",{className:u.card},m().createElement("div",{className:u.accent}),m().createElement("div",{className:u.header},m().createElement("div",{className:u.titleWrap},m().createElement(x.Tooltip,{content:c,placement:"top"},m().createElement("span",{className:u.title},e.name)),s&&s!==e.name&&!s.includes("{{")&&m().createElement("span",{className:u.summary},s),m().createElement("div",{className:u.meta},m().createElement("span",{className:u.state},e.state.toUpperCase()),p&&m().createElement("span",{className:u.badge},p),e.group&&m().createElement("span",{className:u.badgeMuted},e.group))),d&&m().createElement("a",{className:u.runbook,href:d,target:"_blank",rel:"noreferrer",title:"Abrir Runbook","aria-label":"Abrir Runbook"},m().createElement(x.Icon,{name:"book",size:"lg"}))),t&&m().createElement("pre",{className:u.expr,title:e.query},m().createElement("code",null,e.query)),r&&m().createElement("div",{className:u.footer},m().createElement(x.Icon,{name:"clock-nine",size:"sm"}),m().createElement("span",null,e.lastEvaluation?new Date(e.lastEvaluation).toLocaleString():"—")))},v=(e,a,t,r,o)=>({card:g.css`
    position: relative;
    background: rgba(255, 255, 255, 0.03);
    border: 1px solid ${e}55;
    border-radius: ${a}px;
    padding: ${t?"10px 12px 8px":"16px 18px 12px"};
    display: flex;
    flex-direction: column;
    gap: ${t?"6px":"10px"};
    overflow: hidden;
    ${r>0?`max-height: ${r}px;`:""}
    ${o>0?`min-height: ${o}px;`:""}
    box-shadow: 0 2px 12px rgba(0, 0, 0, 0.18);
    transition: transform 120ms ease, box-shadow 120ms ease, border-color 120ms ease;
    &:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px ${e}55;
      border-color: ${e};
    }
  `,accent:g.css`
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 6px;
    background: linear-gradient(180deg, ${e}, ${e}99);
  `,header:g.css`
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 12px;
    padding-left: 8px;
  `,titleWrap:g.css`
    display: flex;
    flex-direction: column;
    gap: 4px;
    min-width: 0;
  `,title:g.css`
    font-weight: 600;
    font-size: 15px;
    line-height: 1.25;
    color: var(--card-fg, #f0f0f0);
    cursor: help;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
  `,summary:g.css`
    font-weight: 400;
    font-size: 12px;
    line-height: 1.3;
    color: rgba(255, 255, 255, 0.7);
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
  `,meta:g.css`
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    align-items: center;
  `,state:g.css`
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 0.08em;
    color: ${e};
  `,badge:g.css`
    font-size: 10px;
    font-weight: 600;
    padding: 2px 8px;
    border-radius: 999px;
    background: ${e}33;
    color: ${e};
    text-transform: uppercase;
  `,badgeMuted:g.css`
    font-size: 10px;
    font-weight: 500;
    padding: 2px 8px;
    border-radius: 999px;
    background: rgba(255, 255, 255, 0.06);
    color: rgba(255, 255, 255, 0.65);
  `,runbook:g.css`
    color: ${e};
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
    padding: 4px 6px;
    transition: background 120ms ease;
    &:hover {
      background: ${e}22;
    }
  `,expr:g.css`
    margin: 0 0 0 8px;
    background: rgba(0, 0, 0, 0.35);
    border: 1px solid rgba(255, 255, 255, 0.06);
    border-radius: 6px;
    padding: 8px 10px;
    font-family: 'Roboto Mono', ui-monospace, SFMono-Regular, Menlo, monospace;
    font-size: 11px;
    line-height: 1.45;
    color: #d4d4dc;
    white-space: pre-wrap;
    word-break: break-all;
    max-height: 96px;
    overflow: auto;
  `,footer:g.css`
    display: flex;
    align-items: center;
    gap: 6px;
    padding-left: 8px;
    font-size: 11px;
    color: rgba(255, 255, 255, 0.55);
  `}),y=d.map(e=>({value:e,label:e.charAt(0).toUpperCase()+e.slice(1)})),w=new c.PanelPlugin(({options:e,width:a,height:t})=>{const[r,o]=(0,u.useState)(null),[n,l]=(0,u.useState)(null);(0,u.useEffect)(()=>{let e=!1;const a=async()=>{try{const a=await async function(){var e,a;const t=await(0,f.getBackendSrv)().get("/api/prometheus/grafana/api/v1/rules"),r=[];for(const p of null!==(e=null===(a=t.data)||void 0===a?void 0:a.groups)&&void 0!==e?e:[]){var o;for(const e of null!==(o=p.rules)&&void 0!==o?o:[]){var n,l,i,s,c,d;if("alerting"!==e.type)continue;const a=null!==(n=e.alerts)&&void 0!==n?n:[],t=e=>{const a=(e||"").toLowerCase();return"alerting"===a||"firing"===a||"pending"===a},o=null!==(l=a.find(e=>["alerting","firing"].includes((e.state||"").toLowerCase())))&&void 0!==l?l:a.find(e=>t(e.state));r.push({name:e.name,query:e.query,state:h(e.state),health:e.health,labels:{...null!==(i=e.labels)&&void 0!==i?i:{},...null!==(s=null==o?void 0:o.labels)&&void 0!==s?s:{}},annotations:{...null!==(c=e.annotations)&&void 0!==c?c:{},...null!==(d=null==o?void 0:o.annotations)&&void 0!==d?d:{}},group:p.name,folder:p.file,lastEvaluation:e.lastEvaluation})}}return r}();e||(o(a),l(null))}catch(a){e||l(a instanceof Error?a.message:String(a))}};a();const t=window.setInterval(a,15e3);return()=>{e=!0,window.clearInterval(t)}},[]);const i=(0,u.useMemo)(()=>{var a,t;if(!r)return[];let o=r;if(e.stateFilter&&e.stateFilter.length>0){const a=new Set(e.stateFilter);a.has("normal")&&a.add("inactive"),o=o.filter(e=>a.has(e.state))}const n=null===(a=e.groupFilter)||void 0===a?void 0:a.trim();if(n)try{const e=new RegExp(n,"i");o=o.filter(a=>{var t;return e.test(null!==(t=a.group)&&void 0!==t?t:"")})}catch{}const l=null===(t=e.labelFilter)||void 0===t?void 0:t.trim();if(l){const e=l.match(/^([\w.\-/]+)\s*=\s*(.+)$/);if(e){const[,a,t]=e;try{const e=new RegExp(t);o=o.filter(t=>{var r;return e.test(null!==(r=t.labels[a])&&void 0!==r?r:"")})}catch{}}else try{const e=new RegExp(l);o=o.filter(a=>{const t=Object.entries(a.labels).map(([e,a])=>`${e}=${a}`).join(",");return e.test(t)})}catch{}}return o},[r,e.stateFilter,e.groupFilter,e.labelFilter]),s=a=>{switch(a){case"firing":return e.colorFiring;case"pending":return e.colorPending;case"nodata":return e.colorNoData;case"error":return e.colorError;default:return e.colorNormal}},c=((e,a,t,r,o)=>({grid:g.css`
    width: ${t}px;
    height: ${r}px;
    overflow: auto;
    display: grid;
    grid-template-columns: repeat(${e}, minmax(0, 1fr));
    grid-auto-rows: ${o>0?`minmax(0, ${o}px)`:"min-content"};
    align-content: start;
    gap: ${a}px;
    padding: 4px;
    box-sizing: border-box;
  `,empty:g.css`
    display: flex;
    align-items: center;
    justify-content: center;
    height: ${r}px;
    color: rgba(255, 255, 255, 0.6);
    font-style: italic;
  `}))(e.columns,e.gap,a,t,e.cardMaxHeight);if(n)return m().createElement(x.Alert,{title:"Falha ao carregar alertas",severity:"error"},n);if(null===r)return m().createElement(x.LoadingPlaceholder,{text:"Carregando alertas..."});if(0===i.length)return e.hideEmptyGroups?null:m().createElement("div",{className:c.empty},m().createElement("span",null,"Nenhum alerta encontrado."));const d={firing:0,pending:1,nodata:2,error:3,normal:4,inactive:4},p=[...i].sort((a,t)=>{switch(e.sortBy){case"name":return a.name.localeCompare(t.name);case"lastEvaluation":{const e=a.lastEvaluation?Date.parse(a.lastEvaluation):0;return(t.lastEvaluation?Date.parse(t.lastEvaluation):0)-e}default:return d[a.state]-d[t.state]||a.name.localeCompare(t.name)}});return m().createElement("div",{className:c.grid},p.map((a,t)=>m().createElement(b,{key:`${a.group}-${a.name}-${t}`,alert:a,color:s(a.state),showExpression:e.showExpression,showFooter:e.showFooter,borderRadius:e.borderRadius,compact:e.compact,maxHeight:e.cardMaxHeight,minHeight:e.cardMinHeight})))}).setPanelOptions(e=>{e.addSliderInput({path:"columns",name:"Colunas",description:"Quantidade de cards por linha",defaultValue:p.columns,settings:{min:1,max:6,step:1},category:["Layout"]}).addNumberInput({path:"gap",name:"Espaçamento entre cards (px)",defaultValue:p.gap,category:["Layout"]}).addNumberInput({path:"borderRadius",name:"Raio das bordas (px)",defaultValue:p.borderRadius,category:["Layout"]}).addBooleanSwitch({path:"compact",name:"Modo compacto",defaultValue:p.compact,category:["Layout"]}).addNumberInput({path:"cardMaxHeight",name:"Altura máxima do card (px)",description:"Limita a altura de cada card. Use 0 para não limitar.",defaultValue:p.cardMaxHeight,settings:{min:0,max:1e3,step:10},category:["Layout"]}).addNumberInput({path:"cardMinHeight",name:"Altura mínima do card (px)",description:"Use 0 para deixar o card se ajustar ao conteúdo.",defaultValue:p.cardMinHeight,settings:{min:0,max:1e3,step:10},category:["Layout"]}).addBooleanSwitch({path:"showExpression",name:"Mostrar expressão (script)",defaultValue:p.showExpression,category:["Conteúdo"]}).addBooleanSwitch({path:"showFooter",name:"Mostrar rodapé (última avaliação)",defaultValue:p.showFooter,category:["Conteúdo"]}).addMultiSelect({path:"stateFilter",name:"Filtrar por estado",description:"Selecione um ou mais estados; deixe vazio para mostrar todos",defaultValue:p.stateFilter,settings:{options:y,allowCustomValue:!1},category:["Filtros"]}).addTextInput({path:"labelFilter",name:"Filtro por label (regex)",description:"Ex.: severity=critical  ou  team=ecommerce",defaultValue:p.labelFilter,category:["Filtros"]}).addTextInput({path:"groupFilter",name:"Filtro por grupo (regex)",description:"Filtra pelo nome do grupo do alert rule",defaultValue:p.groupFilter,category:["Filtros"]}).addRadio({path:"sortBy",name:"Ordenar por",defaultValue:p.sortBy,settings:{options:[{value:"severity",label:"Severidade"},{value:"name",label:"Nome"},{value:"lastEvaluation",label:"Última avaliação"}]},category:["Filtros"]}).addBooleanSwitch({path:"hideEmptyGroups",name:"Ocultar quando vazio",description:"Não renderiza placeholder caso o filtro não retorne alertas",defaultValue:p.hideEmptyGroups,category:["Filtros"]}).addColorPicker({path:"colorFiring",name:"Cor - Firing",defaultValue:p.colorFiring,category:["Cores"]}).addColorPicker({path:"colorPending",name:"Cor - Pending",defaultValue:p.colorPending,category:["Cores"]}).addColorPicker({path:"colorNormal",name:"Cor - Normal/Inactive",defaultValue:p.colorNormal,category:["Cores"]}).addColorPicker({path:"colorNoData",name:"Cor - No Data",defaultValue:p.colorNoData,category:["Cores"]}).addColorPicker({path:"colorError",name:"Cor - Error",defaultValue:p.colorError,category:["Cores"]})});return s})());